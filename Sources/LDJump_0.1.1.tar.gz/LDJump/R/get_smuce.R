get_smuce = function(help, segs, alpha,ll,quant=0.35,rescale = F,constant) { # removed: list.quantile.regs,
  gam = 0.25; eps = 0
  pr1 = predict(LDJump::mod.full,help); pr1[is.na(pr1)] = -1/gam;
  ind.q = which(seq(0.1, 0.5, by = 0.05) == quant)
  pr.cor = predict(LDJump::list.quantile.regs[[ind.q]], data.frame(x = pr1)); pr.cor = ifelse(pr.cor < -4, -4, pr.cor)
  pr.cor.nat = (pr.cor*gam+1)^(1/gam)-eps
  if(constant) {return(list(pr.cor.nat))}
  else {
    temp.cor.back=smuceR(pr.cor.nat, alpha = alpha, family = "gauss", confband = T)
    if(rescale) {
      idx = c(1,2,4:9,11,13:16)
        for(idxs in idx) {
          temp.cor.back[[idxs]] = temp.cor.back[[idxs]]/segs*ll
        }  ## coorection for 1-100% of sequence length
    }
  return(list(temp.cor.back, pr.cor.nat))
  }
}
