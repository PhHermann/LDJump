#! /bin/sh
seqName=$1
nn=$2
lpart=$3
pathLDhat=$4
th=$5
cor=$6
curr=${PWD}
sed -i "1i $nn $lpart 1" $seqName
$pathLDhat/LDhat-master/convert -seq $seqName | tail -n 7 >"temp.txt"
cat "temp.txt" >>"Sums_part_main.txt"

cd $pathLDhat/LDhat-master/lk_files
if [ ! -f "lk_n${nn}_t${th}_rh100_npts201.txt" ]; then
echo "Lookup table is calculated"
$pathLDhat/LDhat-master/complete -n $nn -rhomax 100 -n_pts 201 -theta $th -split $cor
mv new_lk.txt "lk_n${nn}_t${th}_rh100_npts201.txt"
fi

# pathLDhat=$(locate LDhat-master | head -n 1)
# pathLooks=$(locate "lk_n${nn}_t${th}_rh100_npts201.txt" | head -n 1)
cd $curr
echo 0 | $pathLDhat/LDhat-master/pairwise -seq sites.txt -loc locs.txt -lk $pathLDhat/LDhat-master/lk_files/"lk_n${nn}_t${th}_rh100_npts201.txt" >test.txt
head -n 5 outfile.txt | tail -n 1 >temp.txt
cat temp.txt >>resLDHats_pairwise_main.txt




