summary_statistics = function(x,s,segs,seqName,nn,ll, thth,cor = 1,pathLDhat) {
  ix = round(1+(x-1)/segs*ll); ex = round(x/segs*ll)
  sub = subseq(s, start = round(1+(x-1)/segs*ll), end=round(x/segs*ll))
  seqNamePart    = paste(substring(seqName,1,nchar(seqName)-3),"_part.fa",sep="")
  seqNamePartHel = paste(substring(seqName,1,nchar(seqName)-3),"Hel_part.fa",sep="")
  writeXStringSet(sub, seqNamePart, format = "fasta")
  system(paste("cp ", seqNamePart, " ", seqNamePartHel, sep = ""))
  if(length(seg.sites(read.FASTA(seqNamePart)))>1){ # "bash ",
    system(paste(paste(find.package("LDJump"),"/exec/Sums_LDHat_pack.sh", sep=""), seqNamePart,nn,ex-ix+1,pathLDhat,thth,cor,sep=" "))
    samp = read.dna(seqNamePartHel, as.matrix = T, format = "fasta")
    temp = try(DNAbin2genind(samp)); hahe = Hs(temp);
    g2dftemp = genind2df(temp)
    indices = t(combn(1:ncol(g2dftemp),2))
    helper = mapply(fgt_rrate_dpr, x = indices[,1], y = indices[,2], MoreArgs = list(data1 = g2dftemp, data2 = samp))
    if(ncol(helper) > 1) {stats = c(sum(helper[1,]),apply(cbind(sapply(1:(max(indices)-2),function(jj) rowMeans(helper[2:3,indices[,1]==jj])),helper[2:3,indices[,1]==max(indices-1)]),1,mean))}
    else {stats = helper}
  } else {
    stats = rep(NA,3); hahe = NA
    cat("Segregating sites=NA\nAverage PWD=NA\nWatterson theta=NA\nTajima D statistic=NA\nFu and Li D* statistic=NA\nVariance PWD=NA\n",file = paste("Sums_part_main.txt",sep=""),append=T)
    cat("Maximum at 4Ner(region) = 0.000 : Lk = NA\n", file = "resLDHats_pairwise_main.txt",append=T)
  }

  return(c(stats, hahe))
}
